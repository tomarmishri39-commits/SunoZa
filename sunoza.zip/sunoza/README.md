# SUNOZA — Listen • Discover • Enjoy ♡

A modern, responsive, multi-language music discovery and streaming web application built with **HTML5**, **CSS3**, and **Vanilla JavaScript**.

## Folder Structure

```text
sunoza/
├── index.html          # Main application shell & views
├── style.css           # Dark neon glassmorphism theme & responsive layout
├── script.js           # iTunes API search, audio player, queue & localStorage
├── README.md           # Setup & usage instructions
└── assets/
    ├── logo.svg        # Full SUNOZA brand logo
    └── favicon.svg     # Browser favicon & player badge icon
```

## How to Run in VS Code with Live Server

1. Extract the `sunoza` folder (or create a folder named `sunoza` and place all files inside following the structure above).
2. Open the `sunoza` folder in **Visual Studio Code**.
3. Install the **Live Server** extension (by Ritwick Dey) if you haven't already.
4. Right-click `index.html` and choose **"Open with Live Server"** (or click **Go Live** in the bottom-right status bar).
5. Your browser will open SUNOZA automatically!

## Music Data & API Notes

- SUNOZA uses the **iTunes Search API** (`https://itunes.apple.com/search`), which is free, legal, CORS-enabled, and requires **no API keys** or backend server.
- Playable songs stream legal **30-second previews** provided by Apple/iTunes.
- If a track or regional language (such as Maithili or Magahi) has limited or no indexed tracks in the iTunes catalogue, SUNOZA displays an honest unavailable/empty state rather than fake songs.
- Your **Favourite Songs**, **Recently Played**, **Search History**, and **Volume** are saved automatically in your browser's `localStorage`.
